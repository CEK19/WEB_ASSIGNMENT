Thành viên:
1. Nguyễn Trọng Nhân 1914446
2. Vũ Thành Công 1912811
3. Hồ Hữu Trọng 1915672
4. Lê Hoàng Minh Tú 1915812

HẾT VUI :<, kHOX