<?php
session_start();
require_once "./mvc/Bridge.php";
$startApplication = new App();
?>